<?php

/*
 * This script handles any uninstall options needed for wordpress cleanup
 */


// if uninstall.php is not called by WordPress, die
if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}
